[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/VDWRKZWs)
# CS151 PROGRAMMING ASSIGNMENT 5
## Data Analysis Project with Presentation

## Deadlines
* Partner Agreement and Plan: Wednesday 12/3 11:59PM
* Design: Wednesday 12/3 11:59PM
* Final Project: Tuesday 12/9 11:59PM
* Presentation: Wednesday 12/10
* Reflection and Partner Survey: Wednesday 12/10

## OVERVIEW
The problem to be solved will vary from group to group. In this assignment, you will work with 1 other person. There may be 1 group of 3 if there is an odd number of students in the section. The group of 3 will have a larger amount of code to write, but the same amount of work per person.

This project is an opportunity to demonstrate everything you've learned this semester while analyzing real-world data that interests you.

## PURPOSE OF THE ASSIGNMENT
* This assignment will give you practice with the vast majority of Python topics from this course.
* It will also give you one last chance to show that you have learned how to pair program.
* This assignment gives you an opportunity to present your work to your classmates.

## PARTNER AGREEMENT
Every group is required to fully fill out a partner agreement that includes information on how you plan to divide up the work, and when you plan to meet.
* You must assign a lead programmer to each function. This person is the driver on that function.
* Partners should be helping each other on all aspects of the program -- don't leave your partner hanging, or try to do their work for them. Support each other.
* You and your partner should divide the work evenly, ideally working in a pair programming style.
* Because this is a pair programming assignment, all programming must be committed frequently to GitHub.

Partner agreement due at deadline above. You must fill out the provided form in GitHub.
I will tell you if your plan is OK or if you need to make changes.

Be sure to read what you are agreeing to in the partner agreement document.

## DESIGN Submission

You must submit in your GitHub project by the design deadline:

* **partner.md**: Your partner agreement as described in the prior section
* **design.txt**: A list of functions with function name, purpose, parameters (describe), and return value (describe). The names here should match the names used in your partner agreement to list who will be lead programmer. It should be clear what part of the assignment each function represents.
* **A main.py file** that properly reads from your input file, stores that information in an appropriate list (i.e. list of lists), and outputs the first 10 items of the list and the last 10 items of the list to the user so you can see that it works. User input of a filename should be fully implemented with error checking, and no user input or output should occur in the file processing function. You should have 3 implemented functions at this point.

## STRATEGIC AI USE FOR THIS ASSIGNMENT

As a capstone project, this assignment requires you to synthesize everything you've learned. The core programming must demonstrate YOUR mastery of the course concepts.

### What You Must Code Manually (NO AI Assistance)

The following represent core learning objectives and must be written by you:
- All file reading and writing operations
- All list and dictionary creation and manipulation
- All loops for data processing
- All function structures (parameters, return values, function calls)
- The logic for all data analysis calculations
- Data filtering and searching algorithms
- Basic structure of matplotlip graphs

### Where Strategic AI Use Is Appropriate

AI assistance is permitted in these LIMITED areas:

**1. Graphing/Visualization Enhancement**
- Formatting matplotlib graphs to be more visually appealing
- Understanding specific graph customization options (colors, labels, legends)
- Troubleshooting graph display issues
- Example acceptable use: "How do I add a title and axis labels to a matplotlib bar chart?"

**2. Output Formatting Polish**
- Making table displays more readable
- Formatting numbers for display (decimal places, alignment)
- Creating visual separators or organized output
- Example acceptable use: "How do I format output in columns with proper alignment?"

**3. Presentation Materials**
- Brainstorming how to present findings clearly
- Suggesting ways to visualize comparisons
- Creating slide layouts (content must be your analysis)

**4. Custom Question Brainstorming**
- Generating ideas for your custom analysis question
- Discussing feasibility of analysis approaches conceptually
- Example acceptable use: "What interesting patterns could I analyze in restaurant data?"
- **Critical**: You must implement the analysis logic yourself

### What You CANNOT Use AI For
- Writing file I/O code
- Creating data structures (lists, dictionaries)
- Implementing loops or conditionals
- Writing function logic
- Solving the analysis problems
- Debugging your core algorithm logic

### AI Usage Documentation
In your reflection, you must document:
- What AI assistance you used (if any)
- For what specific purpose
- How you ensured you understood any AI-assisted elements
- What you learned from the AI interaction

**Remember**: This is your final demonstration of what YOU have learned. The code should reflect YOUR understanding and capabilities.

## ASSIGNMENT REMINDERS & WORKING AS A PAIR/GROUP
* Follow the programming assignment requirements document for comments, formatting, etc. You will need to add function comments above each function in your code.
* For each function in your PA you MUST list the author of that function in the function header comments. Be very clear about who was involved in each step.
* You will be required to fill out a survey privately about working with your partner (you may NOT take this survey together or show your submission to your partner or any other student).
    * I am expecting you to be honest. I may ask you for a meeting during finals week to discuss.
    * If you are a very bad partner, you will not get full credit for the PA (this includes both taking over the project and not letting your partner drive on their functions, and failing to fulfill your part of the project). You are expected to abide by the original partner agreement or an updated agreement if instructed by the professor to make a change.
* Use GitHub commits to document for all coding. **The leader should be the person to write the code and commit for their function.** 
* If you and your partner are having issues working together, talk to your instructor as soon as it becomes a problem. There is not much the instructor can do to help after the assignment is due or the night of the deadline.

## USABILITY

Follow good usability/HCI principles in designing your input and output. Show that you've learned how to make great output and prompts! It should be easy to understand how to use your program, easy to understand the output, and close to impossible to make your program crash!

For output, unless your assignment specifies that something must be output to a file, you should use your discretion to determine if output to screen or file makes the most sense. If it's too much output to read on screen, it probably needs to be in a file!

Graphs created by the program should be saved to a .jpg file. The user chooses the file name.

## PROGRAMMING REQUIREMENTS
After your design is complete and correct, it's time to start programming and then testing:

1. **Implementation**: Write your program following the below requirements and based on your design.
    * Practice iterative development: Instead of coding everything at once, code 1 part, get it to work right, then start the next part. For instance, code and test one question at a time. Look back at the steps given to you in recent labs.
2. Your program should work for ANY file of this format; if I gave you a new file of the same format, it should work without any changes.
    * You should not assume the number of lines will be identical.
    * Note how the files for your particular problem are delimited.
3. **Input**: The user should provide names of input file, output file (if relevant), and plot files. User input should be error checked as makes sense for your particular problem.
4. **Output**: You must state the purpose of the program. You must make your output as clear as possible.
5. **Output Files**: Be thoughtful about how you format output data in files. Do not simply put the result of a calculation without context. Do not output an entire list as one entity, you need to output each value separately.
6. **Testing**: Does it store the data correctly? Does it calculate the answers correctly? Test it! I certainly will test it when I grade it. Remember that creating a shorter test file with fewer lines may make it easier to double check the correct answer in Excel or by hand, to determine if your program seems to work correctly.
7. **Expectations**: You will use appropriate data structures including a dictionary. Your program will be efficient. For example, it should only read your file once, and will not create unnecessary duplicate lists.
8. **Comments**: In addition to the normal comments (line comments, function header comments, intro comments), **each function should list who was in charge of programming it.** If both partners worked together in pair programming fashion, list both partners but also note who was driver.

## FINAL PRESENTATION

Students will present the results of their data analysis PA to the rest of the class.
* Since each presentation is about different data, you will need to describe the data and the results (what did you learn about the data you analyzed? don't just show values, interpret them. Beware that you don't introduce bias in your interpretation).
* Exact details of the presentation format will be posted on Moodle the week before the presentation.
* Your presentation grade will be based on the content of your presentation, the style of your presentation, and whether or not you pay attention and give feedback on your classmates' presentations during the class period.
* This part of your grade may be different between partners.

**You must upload your group's presentation file(s) to Moodle BY the time listed on Moodle. Only .pptx and .pdf files will be accepted.**

## Earning an E
There are many opportunities to be creative and thoughtful when programming. There is rarely one right way to solve a problem, although usually some approaches are better than others. If I find that you have been particularly creative (in a positive way) or thoughtful in any of the following manners, that will help you earn an E (assuming the program meets requirements):

1. Particularly well commented and organized code
2. Particularly good/clear output, including excellent prompts
3. Particularly excellent design, which includes great efficiency or data structure choices
4. Particularly well done presentation, as long as there is commenting in the code
5. Particularly difficult student-designed question (that works)

## REFLECTION

Write a comprehensive reflection about this capstone programming assignment. This reflection should be MORE SUBSTANTIAL than prior assignment reflections. Be sure to address the questions below.

### Course Integration
Reflect on how this assignment brought together the various aspects of what you learned this semester in computer science:
- Which concepts from the course did you use in this project?
- How did earlier assignments prepare you for this final project?
- What connections did you make between different programming concepts?
- How has your understanding of programming evolved over the semester?

### Technical Challenges and Growth
- What was the hardest technical challenge to solve in this project?
- What was surprisingly easy given how hard it had been earlier in the semester?
- Which programming skills do you feel most confident about now?
- Which areas do you still want to improve?

### Pair Programming Experience
- How did working with a partner enhance or challenge your learning?
- What did you learn from your partner's approach to problem solving?
- How did you divide the work and was that effective?
- What would you do differently in future collaborative programming projects?

### Custom Analysis and Creativity
- What custom analysis question did you design and why?
- What made that question interesting or challenging?
- How did you approach implementing your custom analysis?
- What insights did your analysis reveal about the data?

### AI Collaboration (if applicable)
If you used AI assistance for any permitted aspects:
- What specific AI assistance did you use and for what purpose?
- How did you ensure you understood any AI-assisted elements?
- What did you learn from working with AI tools?
- How did you decide when to use AI vs. solve problems yourself?
- In what ways did AI enhance vs. potentially hinder your learning?

### Data Analysis and Presentation
- What was most interesting about the data you analyzed?
- What surprised you in your findings?
- How did you decide what to emphasize in your presentation?
- What did you learn about communicating technical findings to an audience?

### Looking Forward
- How will you apply what you learned in this course to future CS courses or projects?
- What aspects of programming are you most excited to explore further?
- What advice would you give to future students taking this course?
- How has this course changed your perspective on computer science?

This reflection should demonstrate deep thinking about your learning journey throughout the semester. Be specific with examples from your project and honest about both successes and struggles.

## PROGRAMMING AND PRESENTATION SUBMISSION

**To GitHub by final submission deadline:**
* Your .py file

**To Moodle by presentation deadline:**
* A copy of your presentation (.pptx or .pdf only) and any other necessary presentation materials. Make sure it works on a Windows 11 computer -- you can check it on any computer in DS121 if you aren't sure.

**To Moodle by reflection/partner survey deadline:**
* Your comprehensive reflection (1 per person) following the structure above
* The form rating your and your partners' ability to work as a team. This is where you will reflect on the pair programming aspect of the assignment. There will be a link on Moodle once PA5 has been submitted.